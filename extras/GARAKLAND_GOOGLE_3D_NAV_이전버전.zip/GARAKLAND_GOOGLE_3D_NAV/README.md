# GARAKLAND — Google Maps 3D · 점포 내비게이션 · 상인 홍보 플랫폼

2026-10-29 | 설치 없는 Python 표준 라이브러리 서버 + 순수 HTML/CSS/JS (ES 모듈)

## 바로 실행

Windows: `start_windows.bat` 더블클릭. `http://localhost:8769` 를 Chrome/Edge로 접속. 관리자 API 토큰은 실행 창에 표시됩니다. Linux/macOS: `./start_linux_mac.sh` 또는 `python3 server.py`.

인터넷 없이도 시연용 **모식도/동·층 탐색/점포 검색/CSV/상세정보**는 이용 가능합니다. Google의 실제 지도는 **프로젝트별 유효한 Maps JavaScript API 키 + 활성화된 API + 결제 계정 + 인터넷 연결**이 있어야 표시됩니다. 우측 상단 톱니바퀴에 키를 입력하고 Google 지도 연결을 누르면 Google 위성·지형·3D 보기를 사용할 수 있습니다. 기기 위치는 HTTPS 또는 localhost에서 허용 권한을 받아 사용합니다.

## 구현 범위

- Google Maps JavaScript API 하이브리드 위성 지도 / terrain 지형 지도 / Photorealistic 3D (`maps3d.Map3DElement` + `Marker3DInteractiveElement`)
- 9개 구역 안내, 건물→층→호실 내비게이션 디렉터리 / 검색 및 분류 / 매장 상세
- 실측 완료한 `coordinateStatus=verified` 좌표만 Google 지도 마커 표시, 지도 클릭을 통한 좌표 지정 (다른 상태는 정확 위치로 표시하지 않음)
- 매장 홍보 블로그/홈페이지 새 탭 연결, 없으면 명시적으로 미등록 표시; Google Maps URL 외부 도보 길찾기, 위치 권한 허용시 GPS 표시
- CSV 일괄 업로드/내보내기, 매장 관리 폼, SQLite 지속 저장, 안전한 관리자 토큰 검증, 입력값 유효성 검사
- 3D 실패 시 2D/모식도, 브라우저/모바일 반응형
- 서버 없이 정적 사이트에서 열 때는 CSV 등 임시 데이터가 브라우저별 로컬 저장소에만 저장. 운영 환경에서는 Python 서버를 사용해야 합니다.

## 추가 작업이 반드시 필요한 항목

1. Google Cloud Console → Maps JavaScript API 활성화 + 결제 연결 → **웹사이트 리퍼러 및 API 제한이 걸린 키**를 발급받아 입력. 3D 표현은 지역별 Google 제공 3D 데이터 범위와 브라우저 WebGL 지원에 좌우됩니다.
2. 서울시농수산식품공사로부터 **점포대장·호실 번호·시설/층별 안내도·사용권한**을 정식 확보하고 표준 CSV로 등록. 현재 2개 예시 매장 정보는 출처가 있으나 실측 좌표가 없어 지도 핀 미표시. 9개 구역 모식도는 실제 건물 위치와 일치한다고 주장하지 않습니다.
3. 실내 길찾기는 건물 출입구 위치, 복도 연결 그래프, 계단·엘리베이터 위치, 도면 픽셀과 실측 좌표를 연계한 별도 엔진이 필요합니다. Google의 야외 길찾기만으로는 정확한 실내 동선을 만들 수 없습니다.
4. 운영 배포시 HTTPS, 관리자 사용자 계정/권한, 데이터 백업/감사 로그, 상인 프로필 소유권 검증, 개인 정보 및 광고 고지, Google Maps 할당량·비용 관리 필요.

## CSV 예시

`data/shops.template.csv`의 컬럼을 참고. `id` 고유, `name` 필수, `building`은 `sales/theme1/theme2/theme3/theme4/theme5/office/produce/seafood`, `floor`는 `B2/B1/1F/...`, `room`은 호실, `blogUrl`은 `https://...`, 좌표가 없으면 빈 칸 + `coordinateStatus=unverified`입니다. 정확 좌표를 검증했다면 두 좌표와 검증 출처를 기록하고 `verified`로 변경합니다. 단순 2D 지도 클릭으로 좌표를 지정한 경우 초기 상태는 `approximate`입니다.

## 보안

- 서버는 기본적으로 127.0.0.1에만 바인딩하며 관리자 토큰이 없으면 임의 생성해 서버 터미널에 출력합니다. 공개 서버에 직접 포트를 열지 마세요.
- DB는 `data/garakland.sqlite`에 생기며 ZIP에는 포함하지 않습니다. 백업은 운영자가 별도 보관하세요.
- 키는 `sessionStorage`에 보관(해당 탭 한정), 서버 저장소/CSV에 담지 않습니다. 공개 웹사이트에서 사용하는 Maps JS API 키는 HTTP 리퍼러 및 API 제한이 필요합니다.
- 블로그 링크는 http/https URL만 허용하고 새 창에 `noopener noreferrer`를 설정합니다.

## 중요한 한계

본 프로그램은 **실제 Google 지도 연동 엔진이 구현된 운영 준비형 MVP**이지, 가락시장 전 점포 전수 지도, 승인된 실내 실측 3D 모델 또는 Google의 3D 타일을 다운로드해 재배포하는 패키지가 아닙니다. Google 지도는 라이브 API를 통해서만 표시되며, 실제 키 없이 수행한 오프라인/모의 브라우저 테스트는 키를 넣은 상용 환경의 정상 동작을 보증하지 않습니다.

## 출처/문서

`docs/근거_저작권_한계.md`, `docs/구축설계_검수.md`, `tests/`.

**독립 프로젝트:** Google Maps / 서울특별시농수산식품공사 / Disney와 공식 협력·인증 관계가 아닙니다.

## 실측 3D와 층별 지도 연동 확장

- `data/models3d.json` + `assets/models3d/*.glb`: 승인된 Blender/CAD 3D 모델을 3D Maps 위에 오버레이하는 확장점. 실제 모델은 확보하지 못했기에 빈 설정으로 포함합니다.
- `data/floorplans.json` + `assets/floorplans/*`: 승인된 실제 층별 도면 및 매장의 `indoorX/indoorY`(0~100%) 호실 핀 지원. 승인 도면을 확보하지 못했으므로 현재는 도면 미등록 안내만 표시합니다.
- 설치 가이드 및 검수 목록은 `docs/구축설계_검수.md`에 상세히 기재했습니다.

## Docker (운영자용)

호스트에서 `GARAK_ADMIN_TOKEN`을 강력한 난수로 설정한 후 `docker compose up -d --build`. 기본 Compose 설정은 보안상 포트를 localhost로만 노출합니다. 인터넷 공개 배포는 Nginx/Caddy TLS 프록시와 회원/권한 관리 및 백업 구축 후 수행하세요.

## 이전 시연본

`extras/GARAKLAND_이전_테마파크_MVP.zip`에는 앞선 독립 WebGL·아이소메트릭 MVP가 참고용으로 보존되어 있습니다. 새 Google 지도 통합 시스템의 활성 코드가 아닌 **별도 보관본**입니다.
