@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo GARAKLAND Google 3D NAV
echo The browser will open http://localhost:8769
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:8769'"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 server.py
) else (
  python server.py
)
pause
