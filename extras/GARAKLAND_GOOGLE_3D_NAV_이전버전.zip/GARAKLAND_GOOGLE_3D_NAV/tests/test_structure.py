#!/usr/bin/env python3
"""Static UI integrity and source path checks, no browser dependency."""
from pathlib import Path
from html.parser import HTMLParser
import re, json
root=Path(__file__).resolve().parents[1]
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.scripts=[];self.css=[]
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if 'id' in d:self.ids.append(d['id'])
  if tag=='script' and 'src' in d:self.scripts.append(d['src'])
  if tag=='link' and d.get('rel')=='stylesheet':self.css.append(d.get('href'))
p=Parser();p.feed((root/'index.html').read_text())
assert len(p.ids)==len(set(p.ids)), 'duplicate IDs'
app=(root/'src/app.js').read_text()
used=set(re.findall(r"\$\(['\"]([\w-]+)['\"]\)",app))
dynamic={'googleShopSearch','routeBuilding','routeShop'}
missing=used-set(p.ids)-dynamic
assert not missing, 'missing static DOM IDs: '+repr(sorted(missing))
for ref in p.scripts+p.css:
 assert (root/ref).exists(),ref
floor=json.loads((root/'data/floorplans.json').read_text())
models=json.loads((root/'data/models3d.json').read_text())
assert floor['plans']==[] and models['models']==[]
print(f'PASS DOM: {len(p.ids)} unique IDs, {len(used)} direct JS selectors, {len(p.scripts)} scripts, {len(p.css)} styles')
