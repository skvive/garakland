#!/usr/bin/env python3
import asyncio, os, json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).resolve().parent
BASE=os.getenv('GARAK_URL','http://127.0.0.1:8771')
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  errs=[]
  page.on('pageerror',lambda ex:errs.append(str(ex)))
  await page.goto(BASE,wait_until='domcontentloaded'); await page.wait_for_timeout(1000)
  assert await page.locator('#shopCount').inner_text()=='02',await page.locator('#shopCount').inner_text()
  assert await page.locator('.concept-building').count()==9
  await page.locator('[data-zone="theme5"]').click(); assert '테마 5관' in await page.locator('#detailBody').inner_text()
  await page.locator('[data-tab="stores"]').click(); assert await page.locator('.shop-row').count()==2
  await page.locator('#searchInput').fill('영재');assert await page.locator('.shop-row').count()==1
  await page.locator('.shop-row').first.click(); assert '영재수산' in await page.locator('#detailBody').inner_text()
  assert await page.get_by_role('button',name='블로그 미등록').count()==1
  await page.locator('#searchInput').fill('');await page.locator('[data-tab="explore"]').click();await page.locator('[data-zone="sales"]').click()
  await page.screenshot(path=str(OUT/'preview_desktop.png'),full_page=True)
  await page.locator('[data-tab="guide"]').click();await page.screenshot(path=str(OUT/'preview_guide.png'),full_page=True)
  await page.locator('#adminBtn').click();assert await page.locator('#adminDialog').evaluate('(el)=>el.open')
  await page.locator('[data-admin-tab="sources"]').click();assert await page.locator('#sourceLinks a').count()>=5
  await page.locator('#closeAdminBtn').click();assert not await page.locator('#adminDialog').evaluate('(el)=>el.open')
  # No key must show settings (not falsely claim Google layer)
  await page.locator('[data-mode="3d"]').click();assert await page.locator('#settingsDialog').evaluate('(el)=>el.open')
  await page.locator('#settingsDialog button[aria-label="닫기"]').click()
  assert not errs,errs
  mobile=await browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  mobile.on('pageerror',lambda ex:errs.append(str(ex)))
  await mobile.goto(BASE,wait_until='domcontentloaded');await mobile.wait_for_timeout(600)
  assert await mobile.locator('.concept-building').count()==9
  width=await mobile.evaluate('document.documentElement.scrollWidth');assert width<=392,f'overflow width {width}'
  await mobile.screenshot(path=str(OUT/'preview_mobile.png'),full_page=True)
  assert not errs,errs
  print(json.dumps({'status':'PASS','shops':2,'zones':9,'mobile_scroll_width':width,'js_errors':errs,'screenshots':['preview_desktop.png','preview_guide.png','preview_mobile.png']},ensure_ascii=False))
  await browser.close()
asyncio.run(run())
