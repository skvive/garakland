#!/usr/bin/env python3
"""End-to-end HTTP API security and persistence test, localhost only."""
import sys, json, os, time, tempfile, subprocess, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PORT='8791';BASE=f'http://127.0.0.1:{PORT}';TOKEN='test-token-DoNotUseInProduction'

def call(method,path,payload=None,token=None):
 b=json.dumps(payload).encode() if payload is not None else None
 headers={'Content-Type':'application/json'}
 if token:headers['X-Garak-Admin-Token']=token
 req=urllib.request.Request(BASE+path,data=b,headers=headers,method=method)
 try:
  with urllib.request.urlopen(req,timeout=6) as resp:return resp.status,json.loads(resp.read())
 except urllib.error.HTTPError as err:return err.code,json.loads(err.read())

with tempfile.TemporaryDirectory() as temp:
 env=dict(os.environ,GARAK_DB_PATH=str(Path(temp)/'qa.sqlite'),GARAK_ADMIN_TOKEN=TOKEN,PORT=PORT)
 proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  for _ in range(50):
   try: status,_=call('GET','/api/health');break
   except Exception:time.sleep(.1)
  else:raise RuntimeError('server failed to start')
  assert status==200
  status,data=call('GET','/api/stores');assert status==200 and data['total']==2
  s={'id':'qa-001','name':'검증 테스트 상점','building':'sales','category':'수산','floor':'1F','room':'C-10','description':'<script>alert(1)</script>','address':'서울특별시 송파구 양재대로 932','latitude':37.4943,'longitude':127.1116,'coordinateStatus':'approximate','blogUrl':'https://blog.naver.com/test-store','status':'published'}
  status,data=call('POST','/api/import',{'items':[s]});assert status==403
  status,data=call('POST','/api/import',{'items':[s]},'wrong');assert status==403
  status,data=call('POST','/api/import',{'items':[s]},TOKEN);assert status==200,(status,data)
  assert data['total']==3
  assert any(q['name']=='검증 테스트 상점' for q in data['items'])
  status,data=call('POST','/api/import',{'items':[dict(s,blogUrl='javascript:alert(1)')]},TOKEN);assert status==400,data
  status,data=call('POST','/api/import',{'items':[dict(s,latitude=100.0)]},TOKEN);assert status==400,data
  status,data=call('POST','/api/import',{'items':[dict(s,coordinateStatus='verified',longitude=None)]},TOKEN);assert status==400,data
  status,data=call('POST','/api/import',{'items':[dict(s,id='qa-002'),dict(s,id='qa-002')]},TOKEN);assert status==400,data
  status,data=call('GET','/api/stores?limit=1&offset=2');assert status==200 and len(data['items'])==1
  # transactional nonpartial import
  status,data=call('POST','/api/import',{'items':[dict(s,id='qa-good'),dict(s,id='invalid;<sql>')]},TOKEN);assert status==400
  status,data=call('GET','/api/stores');assert data['total']==3
  print('PASS API: health, SQLite seed, token denial, accepted write, URLs, coordinate validation, duplicate IDs, pagination, rollback')
 finally:proc.terminate();proc.wait(timeout=10)
