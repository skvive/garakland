// Logic-only mocked Google Maps API smoke test. Does NOT verify imagery or GPU rendering.
import assert from 'node:assert/strict';
import {MapEngine} from '../src/map-engine.js';
class Element {constructor(tag='div'){this.tag=tag;this.children=[];this.style={setProperty:()=>{}};this.listeners={};this.className='';}set innerHTML(v){this.html=v;this.children=[];}get innerHTML(){return this.html;}append(v){this.children.push(v);}replaceChildren(...v){this.children=v;}querySelector(s){return new Element(s);}addEventListener(name,f){this.listeners[name]=f;}remove(){this.removed=true;}}
class Map2D {constructor(el,opts){this.el=el;this.options=opts;this.listeners={};}addListener(n,f){this.listeners[n]=f;}panTo(v){this.center=v;}setZoom(z){this.zoom=z;}}
class Marker {constructor(opts){this.opts=opts;}addListener(name,fn){this.onclick=fn;}setMap(map){this.map=map;}}
class Map3DElement extends Element {constructor(options){super('3d');this.options=options;this.center=options.center;} }
class Marker3DInteractiveElement extends Element {constructor(opts){super('marker3d');this.opts=opts;}}
class Model3DElement extends Element {constructor(opts){super('model3d');this.opts=opts;}}
const google={maps:{Map:Map2D,Marker,SymbolPath:{CIRCLE:1},importLibrary:async name=>({Map3DElement,Marker3DInteractiveElement,Model3DElement})}};
globalThis.window={google};globalThis.document={createElement:tag=>new Element(tag)};globalThis.location={href:'https://example.org/'};
const ctx=new Element('root');let clicked=[];let coords=[];
const m=new MapEngine(ctx,{onBuildingClick:id=>clicked.push(id),onShopClick:id=>clicked.push(id),onCoordinatePick:pos=>coords.push(pos)});
assert.equal(m.type,'concept');assert.equal(m.el.querySelector('.concept-map') instanceof Element,true);
await m.connect('dummy');await m.setMode('satellite');assert.equal(m.type,'2d');
const shop={id:'real-001',name:'검증 매장',latitude:37.4943,longitude:127.1116,coordinateStatus:'verified'};
m.setShops([shop]);assert.equal(m.markers.length,1);
m.focus(shop);assert.equal(m.map.zoom,19);
m.startPick();m.map.listeners.click({latLng:{lat:()=>37.4944,lng:()=>127.1117}});assert.equal(coords.length,1);
await m.setMode('3d');await new Promise(r=>setTimeout(r,1));assert.equal(m.type,'3d');assert.equal(m.markers.length,1);
m.setModels([{approved:true,src:'./assets/models3d/market.glb',latitude:37.4943,longitude:127.1116,scale:1}]);await new Promise(r=>setTimeout(r,1));assert.equal(m.modelElements.length,1);
await m.setMode('terrain');assert.equal(m.type,'2d');assert.equal(m.map.options.mapTypeId,'terrain');assert.equal(m.markers.length,1);
await m.setMode('concept');assert.equal(m.type,'concept');
console.log('PASS Google Maps mocked engine: map modes, 3D marker, 3D model, map click coordinate, cleaning markers');
